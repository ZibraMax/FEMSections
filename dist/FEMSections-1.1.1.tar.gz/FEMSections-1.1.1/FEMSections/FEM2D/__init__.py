from .Elemento import *
from .integradorRectangular import *
from .integradorTriangular import *
from .SerendipityC import *
from .CuadrilateroL import *
from .TriangularC import *
from .TriangularL import *
from .Elasticidad import *
from .FEM import *
from .FEM1V import *

def __main__():
    print('Importando FEMSections')